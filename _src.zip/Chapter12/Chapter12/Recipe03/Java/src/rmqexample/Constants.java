package rmqexample;

public interface Constants {
	public static final String RECIPE_NR  = "12/03"; 
	public static final String HEADER     = " ** RabbitmqCookBook - Recipe number " + RECIPE_NR + ". Tracing RabbitMQ ongoing activity. **";
}
