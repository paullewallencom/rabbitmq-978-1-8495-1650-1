package rmqexample;

public interface Constants {
	public static final String RECIPE_NR  = "12/02"; 
	public static final String HEADER     = " ** RabbitmqCookBook - Recipe number " + RECIPE_NR + ". Using RabbitMQ to troubleshoot itself. **";
}
