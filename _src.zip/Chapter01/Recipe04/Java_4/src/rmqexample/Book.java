package rmqexample;

public class Book {
	private int bookID;
	private String bookDescription;
	private String author;
	
	public void setBookID(int value) 
	{
		bookID = value;
	}
	
	public int getBookID()
	{
	  return bookID;	
	}
	
	public void setBookDescription(String value)
	{
		bookDescription = value;
	}
	
	public String getBookDescription()
	{
		return bookDescription;
	}
	
	public void setAuthor(String value)
	{
		author = value;
	}
	
	public String getAuthor()
	{
		return author ;
	}
	
	
		
	
	
}
