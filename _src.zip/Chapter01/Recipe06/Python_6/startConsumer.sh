#!/bin/bash
python PyConsumer.py
