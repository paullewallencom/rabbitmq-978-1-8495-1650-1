# source this file with "." in order to set up the development environment

export RABBITMQ_LOG_BASE=$HOME/rmq/log
export RABBITMQ_MNESIA_BASE=$HOME/rmq/mnesia
export RABBITMQ_ENABLED_PLUGINS_FILE=$HOME/rmq/enabled_plugins
export RABBITMQ_CONFIG_FILE=$HOME/rmq/rabbitmq
