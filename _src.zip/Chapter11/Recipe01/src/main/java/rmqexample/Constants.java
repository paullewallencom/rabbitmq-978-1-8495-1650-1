package rmqexample;

public interface Constants {
	public static final String RECIPE_NR  = "11_01"; 
	public static final String HEADER     = " ** RabbitmqCookBook - Recipe number " + RECIPE_NR + ". Cloud AMQP **";
	public static final String queue   = "myorders_11";
}
