Copy here the RabbitMQ Java Client library JAR files: 

commons-cli-1.1.jar
commons-io-1.2.jar
rabbitmq-client.jar

