/** Automatically generated file. DO NOT MODIFY */
package rmqexample.Chapter04_Recipe07;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}