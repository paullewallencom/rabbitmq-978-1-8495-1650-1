package rmqexample;

public class MapCmd {
	public float longitude;
	public float latitude;
	//TODO: add timestamp, inherit, make polymorphic to support different messages, and so on
}
