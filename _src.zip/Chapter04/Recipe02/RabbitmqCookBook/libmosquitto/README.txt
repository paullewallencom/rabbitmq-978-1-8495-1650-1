Copy the Mosquitto C libray in this directory
https://bitbucket.org/oojah/mosquitto/src - lib directory