//
//  AppDelegate.h
//  RabbitmqCookBook
//
//  Created by Gabriele Santomaggio on 5/22/13.
//  Copyright (c) 2013 Gabriele Santomaggio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
