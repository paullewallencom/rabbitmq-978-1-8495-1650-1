/** Automatically generated file. DO NOT MODIFY */
package rmqexample.chapter04_recipe07_2nd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}