﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WcfLib
{
    public class MachineInfo
    {
        public float CPUsage { get; set; }
        public float Memory { get; set; }
        public DateTime DateEvent { get; set; }
        public String Message { get; set; }


        
    }
}
